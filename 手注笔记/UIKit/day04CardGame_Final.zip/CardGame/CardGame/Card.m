//
//  Card.m
//  CardGame
//
//  Created by tarena on 15/7/6.
//  Copyright (c) 2015年 tarena. All rights reserved.
//

#import "Card.h"

//快捷键：control+command+↑/下
@implementation Card

- (instancetype)initWithSuit:(NSString *)suit andRank:(NSString *)rank{
    self = [super init];
    //if(self)等价形式是：if(self!=nil)
    //if(!self)等价形式是：if(self==nil)
    if(self){
        //做属性的配置
        self.suit = suit;
        self.rank = rank;
        self.faceUp = NO;
        self.matched = NO;
    }
    return self;
}

//为了保证为suit和rank属性赋值时，数据有效，所以
//重写系统默认生成的setter方法，在赋值前做判断
- (void)setSuit:(NSString *)suit{
    //如果suit是合法的花色
    if([[Card allSuit] containsObject:suit]){
        _suit = suit;
    }
}

- (void)setRank:(NSString *)rank{
    if([[Card allRank] containsObject:rank]){
        _rank = rank;
    }
}

//说明cardInfo只读属性的返回值
- (NSString *)cardInfo{
    return [self.suit stringByAppendingString:self.rank];
    
}




+ (NSArray *)allSuit{
    return @[@"♠️",@"❤️",@"♣️",@"♦️"];
}
+ (NSArray *)allRank{
    return @[@"A",@"2",@"3",@"4",@"5",@"6",@"7",@"8",@"9",@"10",@"J",@"Q",@"K"];
}


@end






