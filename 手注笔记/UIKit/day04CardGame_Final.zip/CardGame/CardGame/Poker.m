//
//  Poker.m
//  CardGame
//
//  Created by tarena on 15/7/6.
//  Copyright (c) 2015年 tarena. All rights reserved.
//

#import "Poker.h"
#import "Card.h"

@implementation Poker

//lazy loading 懒加载
//不到使用这个空间，就不要提早来分配空间
//什么时候第一次使用（getter）了，什么时候再分配空间
//重写属性的get方法，实现懒加载
- (NSMutableArray *)allCards{
    //if(!_allCards)等价于if(_allCards==nil)
    if(!_allCards){
        _allCards = [NSMutableArray array];
    }
    return _allCards;
}

//在创建扑克牌时，同时创建出扑克包含的52个纸牌对象
- (instancetype)init{
    self = [super init];
    if (self) {
        //为self.allCards数组填充52张具体的纸牌
        for (NSString *suit in [Card allSuit]) {
            for (NSString *rank in [Card allRank]) {
                Card *c = [[Card alloc]initWithSuit:suit andRank:rank];
                [self.allCards addObject:c];
            }
        }
    }
    return self;
}
@end








