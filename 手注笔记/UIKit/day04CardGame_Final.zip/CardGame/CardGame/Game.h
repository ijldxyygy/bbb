//
//  Game.h
//  CardGame
//
//  Created by tarena on 15/7/6.
//  Copyright (c) 2015年 tarena. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Poker.h"

/*
 类型：游戏类
 作用：依靠制定的扑克牌对象
      1）随机抽取出纸牌
      2）比对纸牌实现业务（具体的玩法）
 属性：
    a。存储所有随机出来的纸牌
 方法：
    a。根据具体的玩法，进行比对纸牌
 
 游戏与扑克牌之间是依赖的关系
 依赖关系一般使用 传参 的方式 来体现
*/
@interface Game : NSObject

//用于记录得分的属性
@property(nonatomic)NSUInteger score;

@property(nonatomic,strong)NSMutableArray *allRandomCards;

-(instancetype)initWithCardCount:(NSUInteger)count inPoker:(Poker *)poker;

//根据点击的牌的位置，进行比对，修改self.allRandomCards
-(void)tapCardAtIndex:(NSUInteger)index;

@end







