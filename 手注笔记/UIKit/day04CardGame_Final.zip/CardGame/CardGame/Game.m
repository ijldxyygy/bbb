//
//  Game.m
//  CardGame
//
//  Created by tarena on 15/7/6.
//  Copyright (c) 2015年 tarena. All rights reserved.
//

#import "Game.h"
#import "Card.h"

@implementation Game

- (NSMutableArray *)allRandomCards{
    if (!_allRandomCards) {
        //创建数组空间
        _allRandomCards = [NSMutableArray array];
    }
    return _allRandomCards;
}

//目标：在创建游戏实例（游戏一开始）时，根据传入
//的扑克牌对象以及要抽取的纸牌的个数，随机出本次游戏的纸牌
-(instancetype)initWithCardCount:(NSUInteger)count inPoker:(Poker *)poker{
    self = [super init];
    if (self) {
        self.score = 0;
        for (NSUInteger i=0; i<count; i++) {
            //随机从poker中抽取一个纸牌
            //将抽取的纸牌添加到self.allRandomCards中
            // 随机出一个下标
            unsigned int  index = arc4random()%poker.allCards.count;
            Card *randomCard = poker.allCards[index];
            //将随机出的纸牌添加到数组中
            [self.allRandomCards addObject:randomCard];
            //将抽取出的牌从poker中移除
            [poker.allCards removeObjectAtIndex:index];
        }
    }
    return self;
}


/*
 1.根据点击的位置，找到点击的牌对象card
 2.if面朝上
    将纸牌翻回背朝上
 3.else（面朝下）
    a。将纸牌翻回到面朝上
    b。遍历数组，获取除本次点击的其余所有牌
        如果 其余牌 面朝上 比对
            如果 两张牌 花色相同
                设置两张牌matched为YES
            如果 两张牌 大小相同
                设置两张牌matched为YES
            else
                其余的那张牌翻回背朝上
*/
- (void)tapCardAtIndex:(NSUInteger)index{
    Card *chooseCard = self.allRandomCards[index];
    if (chooseCard.isFaceUp) {//面朝上
        chooseCard.faceUp = NO;
    }else{//面朝下
        chooseCard.faceUp = YES;
        for (NSUInteger i=0; i<self.allRandomCards.count; i++) {
            if(i!=index){
                Card *otherCard = self.allRandomCards[i];
                if (otherCard.isFaceUp&&!otherCard.isMatched) {
                    if ([chooseCard.suit isEqualToString:otherCard.suit]) {
                        //设置两张牌被匹配了
                        chooseCard.matched = YES;
                        otherCard.matched = YES;
                        self.score+=1;
                    }else if([chooseCard.rank isEqualToString:otherCard.rank]){
                        chooseCard.matched = YES;
                        otherCard.matched =YES;
                        self.score+=4;
                    }else{
                        otherCard.faceUp = NO;
                    }
                }
            }
        }
    }
    
}

@end








