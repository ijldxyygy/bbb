//
//  GameViewController.m
//  CardGame
//
//  Created by tarena on 15/7/3.
//  Copyright (c) 2015年 tarena. All rights reserved.
//

#import "GameViewController.h"
#import "Game.h"
#import "Poker.h"
#import "Card.h"

@interface GameViewController ()
//为了统一管理系统创建的12个按钮，所以准备了一个数组来存储12个按钮的引用
//数组不是系统创建的，是我们自己为了存引用添加的，所以要用strong
//但是数组中存储的所有按钮的引用是weak的，因为按钮是系统创建实例的
@property (strong, nonatomic) IBOutletCollection(UIButton) NSArray *allButtons;
//增加游戏，增加扑克
@property(nonatomic,strong)Game *game;
@property(nonatomic,strong)Poker *poker;
@property (weak, nonatomic) IBOutlet UILabel *scoreLabel;

@end

@implementation GameViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //创建poker实例
    //此句等同于买了一副新的扑克牌
    self.poker = [[Poker alloc]init];
    //创建game实例
    //此句等同于开始新游戏
    self.game = [[Game alloc]initWithCardCount:self.allButtons.count inPoker:self.poker];
    [self showCards];
}

//显示随机的的纸牌到按钮上
-(void)showCards{
    for (UIButton *button in self.allButtons) {
        // 获取按钮在数组中的下标
        NSInteger index = [self.allButtons indexOfObject:button];
        //按照这个下标找到对应的纸牌
        Card *c = self.game.allRandomCards[index];
        //将纸牌的花色和大小  显示到按钮上
        [button setTitle:[self titleForCard:c] forState:UIControlStateNormal];
        [button setBackgroundImage:[UIImage imageNamed:[self imageNameForCard:c]] forState:UIControlStateNormal];
        //matched  YES    NO
        //enabled  NO     YES
        button.enabled = !c.matched;
    }
    //显示分数
    self.scoreLabel.text = [NSString stringWithFormat:@"分数:%ld",self.game.score];
}
- (IBAction)touchCard:(UIButton *)sender {
    NSInteger index = [self.allButtons indexOfObject:sender];
    [self.game tapCardAtIndex:index];
    [self showCards];
}
// 根据传入的纸牌，返回要显示的图片名称
-(NSString *)imageNameForCard:(Card *)c{
    return c.isFaceUp?@"cardfront.png":@"cardback.png";
}
// 根据传入的纸牌，返回要显示的title
-(NSString *)titleForCard:(Card *)c{
    return c.isFaceUp?c.cardInfo:@"";
}









@end
